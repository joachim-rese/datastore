def score(input_data):
    return {'predictions': [{'values': [['Just a test']]}]}

